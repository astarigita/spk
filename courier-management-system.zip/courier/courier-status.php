<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Courier / Cargo Tracking Script in PHP - Ver 0.97</title>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<script type="text/JavaScript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	left:178px;
	top:347px;
	width:632px;
	height:89px;
	z-index:1;
}
.style1 {
	color: #008000;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table border="0" cellpadding="0" cellspacing="0" align="center" width="900">
  <tbody><tr>
    <td width="900">
	
<table border="0" cellpadding="0" cellspacing="0" width="900">
<tbody><tr>
<td>
<img src="images/trheader.jpg" height="109" width="900"></td>
</tr>
<tr>
<td bgcolor="#FFCC00">&nbsp;</td>
</tr>
</tbody></table>
	</td>
  </tr>
  
  <tr>
    <td bgcolor="#FFFFFF"><table border="0" cellpadding="1" cellspacing="1" align="center" width="98%">
      <tbody><tr>
        <td class="Partext1">&nbsp;</td>
      </tr>
      <tr>
        <td class="Partext1"><div class="Partext1" align="center">
          <h3><strong>Tracking Shipment </strong></h3>
        </div></td>
      </tr>
      
      <tr>
        <td class="Partext1"><br>
	  




 
  
          <table border="0" cellpadding="1" cellspacing="1" height="30" align="center" width="73%">
          <tbody><tr>
            <td><div onClick="MM_openBrWindow('printview1.php?id=2233','pv','scrollbars=yes,resizable=yes,width=600,height=500')" align="right"><a href="#" class="gentxt">Printable Version </a></div></td>
          </tr>
        </tbody></table>
          
        
		  <table class="blackbox" border="0" cellpadding="1" cellspacing="1" align="center" width="550">
            <tbody><tr>
              <td bgcolor="#FEE9A9" height="27"><strong>&nbsp;Consignment No</strong> : 2233</td>
            </tr>
            <tr>
              <td><br>
                <table border="0" cellpadding="3" cellspacing="0" align="center" width="520">
                  <tbody><tr>
                    <td><table border="0" cellpadding="3" cellspacing="0" width="250">
                      <tbody><tr>
                        <td class="paratext"><em><strong>Shipper </strong></em></td>
                      </tr>
                      <tr>
                        <td class="paratext"><em>Tousif Khan</em></td>
                      </tr>
                      <tr>
                        <td class="paratext"><em>020 253623</em></td>
                      </tr>
                      <tr>
                        <td class="paratext"><em>10 metro tower, kondwa</em></td>
                      </tr>
                    </tbody></table></td>
                    <td><table border="0" cellpadding="3" cellspacing="0" width="250">
                      <tbody><tr>
                        <td class="paratext"><em><strong>Receiver</strong></em></td>
                      </tr>
                      <tr>
                        <td class="paratext"><em>Rizwan Ahmed</em></td>
                      </tr>
                      <tr>
                        <td class="paratext"><em>020 88552233</em></td>
                      </tr>
                      <tr>
                        <td class="paratext"><em>03 merta tower kondwa</em></td>
                      </tr>
                    </tbody></table></td>
                  </tr>
                </tbody></table>
                <table border="0" cellpadding="3" cellspacing="5" align="center" width="520">
                <tbody><tr>
                  <td><strong>Origin</strong></td>
                  <td>XYZ</td>
                  <td><strong>Destination</strong></td>
                  <td>ABC</td>
                </tr>
                <tr>
                  <td colspan="4" bgcolor="#F0F0F0" height="1"></td>
                  </tr>
                <tr>
                  <td><strong>Pickup date/Time</strong></td>
                  <td>18/01/2011<span class="gentxt"> -
                      4                  </span></td>
                  <td><strong>Weight</strong></td>
                  <td>20 kg</td>
                </tr>
                <tr>
                  <td colspan="4" bgcolor="#F0F0F0" height="1"></td>
                  </tr>
                <tr>
                  <td><strong>Courier</strong></td>
                  <td>XYZ</td>
                  <td><strong>Status</strong></td>
                  <td><span class="style1">In Transit</span></td>
                </tr>
                <tr>
                  <td colspan="4" bgcolor="#F0F0F0" height="1"></td>
                  </tr>
                
				 <tr>
				   <td><strong>Expected Delivery Date</strong></td>
				   <td colspan="3">25/01/2011</td>
				   </tr>
				 <tr>
                  <td colspan="4" bgcolor="#F0F0F0" height="1"></td>
                  </tr>
				
				
				
				              </tbody></table>
                <br></td>
            </tr>
          </tbody></table>
		  <p>
		    		    
		    
		    		    </p>
		  <table class="blackbox" cellpadding="2" cellspacing="0" align="center" width="90%">
            <tbody><tr>
              <td bgcolor="#D9F2FF" align="right"><div align="center">Date</div></td>
              <td bgcolor="#D9F2FF" align="right"><div align="center">Time </div></td>
              <td bgcolor="#D9F2FF"><div align="center">Location </div></td>
              <td bgcolor="#D9F2FF"><div align="center">Status</div></td>
              <td bgcolor="#D9F2FF"><div align="center">Comments</div></td>
            </tr>
                                    </tbody></table>
	  
		  
          <table cellpadding="2" cellspacing="2" align="center" width="90%">
            <tbody><tr>
              <td bgcolor="#FFFFFF" align="right" width="29%"><div align="center"></div></td>
              <td bgcolor="#FFFFFF" align="right" width="20%"><div align="center"></div></td>
              <td bgcolor="#FFFFFF" width="28%"><div align="center"></div></td>
              <td bgcolor="#FFFFFF" width="23%"><div align="center"></div></td>
            </tr>
          </tbody></table></td>
        </tr>
      <tr>
        <td class="Partext1">&nbsp;</td>
        </tr>
      <tr>
        <td>&nbsp;</td>
        </tr>
    </tbody></table>      </td>
  </tr>
  <tr>
    <td><table border="0" cellpadding="0" cellspacing="0" align="center" width="900">
  <tbody><tr>
    <td bgcolor="#2284d5" height="40" width="476">&nbsp;</td>
    <td bgcolor="#2284d5" width="304">&nbsp;</td>
  </tr>
</tbody></table>
</td>
  </tr>
</tbody></table>


</body></html>